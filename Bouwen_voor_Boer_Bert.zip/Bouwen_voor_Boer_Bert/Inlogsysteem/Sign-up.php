<?php
session_start();

define('DB_HOST', 'localhost');
define('DB_PORT', 3306);
define('DB_NAME', 'Reserveringen');
define('DB_USER', 'root');
define('DB_PASS', '');


global $PDO;

try {
    // Use the constants in the PDO connection string
    $PDO = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
    // set the PDO message mode to exception
    $PDO->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}




$wachtwoord = isset($_REQUEST["wachtwoord"]) ? trim($_REQUEST["wachtwoord"]) :"";
$Herhaal_wachtwoord = isset($_REQUEST["Herhaal_wachtwoord"]) ? trim($_REQUEST["Herhaal_wachtwoord"]) :"";

if ($wachtwoord == $Herhaal_wachtwoord) {
    // $sqlSignUp = "INSERT INTO Users (Username, pwd, Email) VALUES (:Username, :pwd, :Email)";
    // $stmtSignUp = $PDO->prepare($sqlSignUp);
    // $stmtSignUp->bindParam(":pwd", $Wachtwoord, PDO::PARAM_STR) ;
    // $stmtSignUp->bindParam(":Username", $Usernamec, PDO::PARAM_STR) ;
    // $stmtSignUp->bindParam(":Email", $Email, PDO::PARAM_STR) ;
    // $stmtSignUp->execute() ;

} else {  
    $_SESSION['Error'] = "Wachtwoorden komen niet overeen";
    echo "<script>window.history.go(-1)</script>";
}

